package com.example.flappybirdsapedition;

import android.content.Context;
import android.content.res.Resources;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Rect;
import android.util.DisplayMetrics;
import android.view.Display;
import android.view.WindowManager;

import java.util.ArrayList;

public class AppConstans {

    public static BackgroundImage backgroundImage;
    static BitmapBank bitmapBank;
    static int SCREEN_WIDTH, SCREEN_HEIGHT;
    static int gravity;
    static int VELOCITY_WHEN_JUMPED;
    static GameEngine gameEngine;

    public static void initialization(Context context) {
        setScreenSize(context);
        bitmapBank = new BitmapBank(context.getResources());
        gameEngine = new GameEngine();
        gravity = 3;
        VELOCITY_WHEN_JUMPED = -40;
    }

    public static BitmapBank getBitmapBank() {
        return bitmapBank;
    }

    public static GameEngine getGameEngine() {
        return gameEngine;
    }

    private static void setScreenSize(Context context) {
        WindowManager wm = (WindowManager) context.getSystemService(Context.WINDOW_SERVICE);
        Display display = wm.getDefaultDisplay();
        DisplayMetrics metrics = new DisplayMetrics();
        display.getMetrics(metrics);
        SCREEN_WIDTH = metrics.widthPixels;
        SCREEN_HEIGHT = metrics.heightPixels;
    }

    public static void updateGameEngine(Canvas canvas) {
        GameEngine gameEngine = getGameEngine();
        gameEngine.updateAndDrawBackgroundImage(canvas);
        //gameEngine.updateAndDrawPipes(canvas);
        gameEngine.updateAndDrawBird(canvas);
    }
}