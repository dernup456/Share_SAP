package com.example.flappybirdsapedition;

import android.graphics.Canvas;

public class GameEngine {

    BackgroundImage backgroundImage;
    Bird bird;

    static int gameState;

    public GameEngine() {
        backgroundImage = new BackgroundImage();
        bird = new Bird() {
            @Override
            public void draw(Canvas canvas) {
                // Zeichne den Vogel
            }
        };
        //pipe = new Pipe(AppConstans.getBitmapBank().getPipeUpper(),
        //        AppConstans.SCREEN_WIDTH, 0); // Beispielwerte für X und Y
        gameState = 0;
    }

    public void updateAndDrawBackgroundImage(Canvas canvas) {
        backgroundImage.setX(backgroundImage.getX() - backgroundImage.getVelocity());
        if (backgroundImage.getX() < -AppConstans.getBitmapBank().getBackgroundWidth()) {
            backgroundImage.setX(0);
        }

        canvas.drawBitmap(AppConstans.getBitmapBank().getBackground_game(), backgroundImage.getX(),
                backgroundImage.getY(), null);

        if (backgroundImage.getX() < (AppConstans.getBitmapBank().getBackgroundWidth() - AppConstans.SCREEN_WIDTH)) {
            canvas.drawBitmap(AppConstans.getBitmapBank().getBackground_game(), backgroundImage.getX() +
                    AppConstans.getBitmapBank().getBackgroundWidth(), backgroundImage.getY(), null);
        }
    }

    public static void updateAndDrawPipes(Canvas canvas) {

    }

    public void updateAndDrawBird(Canvas canvas) {
        if (gameState == 1) {
            if (bird.getY() < (AppConstans.SCREEN_HEIGHT - AppConstans.getBitmapBank().getBirdHeight())
                    || bird.getVelocity() < 0) {
                bird.setVelocity(bird.getVelocity() + AppConstans.gravity);
                bird.setY(bird.getY() + bird.getVelocity());
            }
        }

        int currentFrame = bird.getCurrentFrame();
        canvas.drawBitmap(AppConstans.getBitmapBank().getBird(currentFrame), bird.getX(), bird.getY(), null);
        currentFrame++;

        if (currentFrame >= bird.maxFrame) {
            currentFrame = 0;
        }
        bird.setCurrentFrame(currentFrame);
    }
}
