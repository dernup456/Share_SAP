package com.example.flappybirdsapedition;

import android.graphics.Bitmap;
import android.graphics.Canvas;
import java.util.ArrayList;

public abstract class Bird {
    private ArrayList<Bitmap> arrBms = new ArrayList<>();

    private int birdX, birdY, currentFrame, velocity;
    public static int maxFrame;

    public Bird (){
        birdX = AppConstans.SCREEN_WIDTH/2 - AppConstans.getBitmapBank().getBirdWidth()/2;
        birdY = AppConstans.SCREEN_HEIGHT/2 - AppConstans.getBitmapBank().getBirdHeight()/2;
        currentFrame = 0;
        maxFrame = 3;
        velocity = 0;
    }

    public abstract void draw(Canvas canvas);

    public ArrayList<Bitmap> getArrBms() {
        return arrBms;
    }

    public void setArrBms(ArrayList<Bitmap> arrBms) {
        this.arrBms = arrBms;
    }

    public int getVelocity(){
        return velocity;
    }

    public void setVelocity (int velocity){
        this.velocity = velocity;
    }

    public int getCurrentFrame(){
        return currentFrame;
    }
    public void setCurrentFrame(int currentFrame){
        this.currentFrame = currentFrame;
    }

    public int getX(){
        return birdX;
    }

    public int getY(){
        return birdY;
    }

    public void setX(int birdX){
        this.birdX = birdX;
    }

    public void setY(int birdY){
        this.birdY = birdY;
    }
}
